const express = require('express');
const router = express.Router();
const fetch = (...args) => import('node-fetch').then(({default: f})=>f(...args));
const TMDB_KEY = process.env.TMDB_API_KEY || '';
const TMDB_BASE = 'https://api.themoviedb.org/3';

router.get('/search', async (req,res)=>{
  const q = req.query.q || '';
  if (!q) return res.status(400).json({ error: 'q parameter required' });
  try {
    const url = `${TMDB_BASE}/search/movie?api_key=${TMDB_KEY}&query=${encodeURIComponent(q)}&include_adult=false`;
    const r = await fetch(url);
    const data = await r.json();
    res.json(data);
  } catch (err) { res.status(500).json({ error: 'Failed to search movies' }); }
});

router.get('/:id', async (req,res)=>{
  const id = req.params.id;
  try {
    const url = `${TMDB_BASE}/movie/${id}?api_key=${TMDB_KEY}&append_to_response=credits,videos,recommendations`;
    const r = await fetch(url);
    const data = await r.json();
    res.json(data);
  } catch (err) { res.status(500).json({ error: 'Failed to fetch movie details' }); }
});

module.exports = router;
