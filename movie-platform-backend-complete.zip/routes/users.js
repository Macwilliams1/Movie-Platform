const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');

router.get('/me', auth, async (req,res)=>{
  const user = await User.findById(req.user.id).select('-passwordHash -refreshTokens');
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

router.post('/me/favorites', auth, async (req,res)=>{
  const { movieId } = req.body;
  if (!movieId) return res.status(400).json({ error: 'movieId required' });
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (!user.favorites.includes(movieId)) { user.favorites.push(movieId); await user.save(); }
  res.json({ favorites: user.favorites });
});

router.delete('/me/favorites/:movieId', auth, async (req,res)=>{
  const { movieId } = req.params;
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  user.favorites = user.favorites.filter(m => m !== movieId);
  await user.save();
  res.json({ favorites: user.favorites });
});

router.post('/me/watchlists', auth, async (req,res)=>{
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  const user = await User.findById(req.user.id);
  user.watchlists.push({ name, movies: [] });
  await user.save();
  res.status(201).json(user.watchlists);
});

router.put('/me/watchlists/:watchlistId', auth, async (req,res)=>{
  const { watchlistId } = req.params;
  const { movieId, action } = req.body;
  const user = await User.findById(req.user.id);
  const wl = user.watchlists.id(watchlistId);
  if (!wl) return res.status(404).json({ error: 'Watchlist not found' });
  if (action === 'add') { if (!wl.movies.includes(movieId)) wl.movies.push(movieId); }
  else if (action === 'remove') { wl.movies = wl.movies.filter(m => m !== movieId); }
  await user.save();
  res.json(wl);
});

router.delete('/me/watchlists/:watchlistId', auth, async (req,res)=>{
  const { watchlistId } = req.params;
  const user = await User.findById(req.user.id);
  user.watchlists = user.watchlists.filter(w => w._id.toString() !== watchlistId);
  await user.save();
  res.json({ watchlists: user.watchlists });
});

module.exports = router;
