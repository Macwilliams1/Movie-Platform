const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'secret';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'refreshsecret';
const ACCESS_EXPIRES = '15m';
const REFRESH_EXPIRES = '7d';

function signAccess(user){ return jwt.sign({ id: user._id, email: user.email }, JWT_SECRET, { expiresIn: ACCESS_EXPIRES }); }
function signRefresh(user){ return jwt.sign({ id: user._id }, JWT_REFRESH_SECRET, { expiresIn: REFRESH_EXPIRES }); }

router.post('/register', async (req,res)=>{
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ error: 'Email already in use' });
    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, passwordHash: hash });
    res.status(201).json({ id: user._id, name: user.name, email: user.email });
  } catch(err){ res.status(500).json({ error: 'Server error' }) }
});

router.post('/login', async (req,res)=>{
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const accessToken = signAccess(user);
    const refreshToken = signRefresh(user);
    user.refreshTokens.push({ token: refreshToken, createdAt: new Date() });
    await user.save();
    res.cookie('refreshToken', refreshToken, { httpOnly: true, secure: false, maxAge: 7*24*3600*1000 });
    res.json({ accessToken, user: { id: user._id, name: user.name, email: user.email } });
  } catch(err){ res.status(500).json({ error: 'Server error' }) }
});

router.post('/refresh', async (req,res)=>{
  try {
    const token = req.cookies.refreshToken || req.body.refreshToken;
    if (!token) return res.status(401).json({ error: 'No refresh token' });
    const payload = jwt.verify(token, JWT_REFRESH_SECRET);
    const user = await User.findById(payload.id);
    if (!user) return res.status(401).json({ error: 'Invalid refresh token' });
    const found = user.refreshTokens.find(r=> r.token === token);
    if (!found) return res.status(401).json({ error: 'Refresh token not recognized' });
    const accessToken = signAccess(user);
    res.json({ accessToken });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid refresh token' });
  }
});

router.post('/logout', async (req,res)=>{
  try {
    const token = req.cookies.refreshToken || req.body.refreshToken;
    if (!token) return res.json({ ok: true });
    try { const payload = jwt.verify(token, JWT_REFRESH_SECRET); const user = await User.findById(payload.id); if (user) { user.refreshTokens = user.refreshTokens.filter(r=> r.token !== token); await user.save(); } } catch(e){}
    res.clearCookie('refreshToken');
    res.json({ ok: true });
  } catch(err){ res.status(500).json({ error: 'Server error' }) }
});

module.exports = router;
