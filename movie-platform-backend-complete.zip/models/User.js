const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, index: true },
  passwordHash: { type: String, required: true },
  favorites: [{ type: String }],
  watchlists: [{ name: String, movies: [{ type: String }] }],
  refreshTokens: [{ token: String, createdAt: Date }],
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('User', UserSchema);
