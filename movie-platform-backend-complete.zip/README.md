# Movie Platform Backend (Complete Scaffold)

Features: JWT access+refresh, favorites, watchlists, TMDB proxy, Docker.

See .env.example and docker-compose.yml to run locally.
