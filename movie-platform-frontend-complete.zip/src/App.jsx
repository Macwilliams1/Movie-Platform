import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Search from './pages/Search'
import Movie from './pages/Movie'
import Login from './pages/Login'
import Watchlists from './pages/Watchlists'
export default function App(){ return (<div className='app'><header className='header'><Link to='/'><h1>Movie Platform</h1></Link><nav><Link to='/search'>Search</Link> | <Link to='/watchlists'>Watchlists</Link> | <Link to='/login'>Login</Link></nav></header><main className='container'><Routes><Route path='/' element={<Home/>} /><Route path='/search' element={<Search/>} /><Route path='/movie/:id' element={<Movie/>} /><Route path='/login' element={<Login/>} /><Route path='/watchlists' element={<Watchlists/>} /></Routes></main></div>) }
