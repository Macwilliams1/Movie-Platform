import React, { useState } from 'react'
import api from '../api/api'
import { useNavigate } from 'react-router-dom'
export default function Login(){ const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState(null); const nav=useNavigate();
  const submit=async(e)=>{ e.preventDefault(); setError(null); try{ const res=await api.post('/auth/login',{ email, password }); localStorage.setItem('accessToken', res.data.accessToken); nav('/'); }catch(err){ setError(err.response?.data?.error || 'Login failed') } }
  return (<div><h2>Login</h2><form onSubmit={submit}><input placeholder='email' value={email} onChange={e=>setEmail(e.target.value)} /><br/><input type='password' placeholder='password' value={password} onChange={e=>setPassword(e.target.value)} /><br/><button type='submit'>Login</button></form>{error&&<p style={{color:'red'}}>{error}</p>}</div>) }
