import React, { useEffect, useState } from 'react'
import api from '../api/api'
export default function Watchlists(){ const [watchlists,setWatchlists]=useState([]); const [name,setName]=useState('');
  useEffect(()=>{ api.get('/users/me').then(r=> setWatchlists(r.data.watchlists || []) ).catch(()=>{}) },[])
  const create=async()=>{ if(!name) return; const res=await api.post('/users/me/watchlists',{ name }); setWatchlists(res.data); setName('') }
  return (<div><h2>Your Watchlists</h2><input placeholder='New list name' value={name} onChange={e=>setName(e.target.value)} /><button onClick={create}>Create</button><ul>{watchlists.map(w=> (<li key={w._id}><strong>{w.name}</strong> ({w.movies.length} movies)</li>))}</ul></div>) }
