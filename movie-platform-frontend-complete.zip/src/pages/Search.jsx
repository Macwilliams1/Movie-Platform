import React, { useState } from 'react'
import api from '../api/api'
import { Link } from 'react-router-dom'
export default function Search(){ const [q,setQ]=useState(''); const [results,setResults]=useState([]); const [loading,setLoading]=useState(false); const [error,setError]=useState(null);
  const doSearch=async()=>{ if(!q) return; setLoading(true); setError(null); try{ const res=await api.get(`/movies/search?q=${encodeURIComponent(q)}`); setResults(res.data.results||[]); }catch(err){ setError('Search failed') }finally{ setLoading(false) } }
  return (<div><h2>Search</h2><div style={{display:'flex',gap:8}}><input value={q} onChange={e=>setQ(e.target.value)} placeholder='Search movies...' /><button onClick={doSearch}>Search</button></div>{loading&&<p>Loading...</p>}{error&&<p style={{color:'red'}}>{error}</p>}<ul>{results.map(m=>(<li key={m.id}><Link to={`/movie/${m.id}`}>{m.title} ({m.release_date?.slice(0,4)})</Link></li>))}</ul></div>) }
