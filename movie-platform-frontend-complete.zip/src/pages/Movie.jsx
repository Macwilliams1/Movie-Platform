import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import api from '../api/api'
export default function Movie(){ const { id } = useParams(); const [movie,setMovie]=useState(null); const [loading,setLoading]=useState(true); const [error,setError]=useState(null); const [favorited,setFavorited]=useState(false);
  useEffect(()=>{ setLoading(true); api.get(`/movies/${id}`).then(r=>setMovie(r.data)).catch(()=>setError('Failed to load movie')).finally(()=>setLoading(false)) },[id]);
  useEffect(()=>{ api.get('/users/me').then(r=>{ const fav=(r.data.favorites||[]).includes(String(id)); setFavorited(fav) }).catch(()=>{}) },[id]);
  const toggleFav=async ()=>{ try{ if(favorited){ await api.delete(`/users/me/favorites/${id}`); setFavorited(false) } else { await api.post('/users/me/favorites',{ movieId: id }); setFavorited(true) } }catch(err){ alert('Auth required or error') } }
  if(loading) return <p>Loading...</p>; if(error) return <p style={{color:'red'}}>{error}</p>; if(!movie) return null;
  return (<div><h2>{movie.title} ({movie.release_date?.slice(0,4)})</h2><p>{movie.overview}</p><button onClick={toggleFav}>{favorited ? 'Remove Favorite' : 'Add to Favorites'}</button></div>) }
