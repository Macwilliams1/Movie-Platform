import axios from 'axios';
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';
const api = axios.create({ baseURL: API_BASE, withCredentials: true });
api.interceptors.request.use(cfg => { const t = localStorage.getItem('accessToken'); if (t) cfg.headers.Authorization = `Bearer ${t}`; return cfg; });
api.interceptors.response.use(r=>r, async err=>{ const original = err.config; if (err.response && err.response.status === 401 && !original._retry){ original._retry = true; try{ const refresh = await api.post('/auth/refresh'); if(refresh.data?.accessToken){ localStorage.setItem('accessToken', refresh.data.accessToken); original.headers.Authorization = `Bearer ${refresh.data.accessToken}`; return api(original); } }catch(e){} } return Promise.reject(err); });
export default api;
